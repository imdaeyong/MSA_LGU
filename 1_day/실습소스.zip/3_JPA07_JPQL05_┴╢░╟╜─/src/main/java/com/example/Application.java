package com.example;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.entity.Member;
import com.example.entity.Team;

@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
		
		EntityManagerFactory emf =
				Persistence.createEntityManagerFactory("hello");
		//////////////////////////////////////////////////
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		try {
					
			Team team = new  Team();
			team.setName("team1");
			
			Team team2 = new  Team();
			team2.setName("team2");
			
			em.persist(team);
			em.persist(team2);
			
			Member m1 = new Member("aaa1", 7, team);
			Member m2 = new Member("aaa2", 5, team2);
			Member m3 = new Member("aaa3", 60, team);
			Member m4 = new Member("aaa4", 70, team2);
			
			em.persist(m1);
			em.persist(m2);
			em.persist(m3);
			em.persist(m4);
			
			//1. 부등 CASE
			String query = "select case when m.age <= 10 then '학생요금' "  +
					              "     when m.age >= 60 then '경로요금 ' " +
					              "     else '일반요금' " + 
					        "end  " +
					        "from Member m";
			List<String> result = em.createQuery(query, String.class).getResultList();
			for (String s : result) {
				System.out.println(s);
			}
			
			//2.  동등 CASE ==> then절에서 연산시 () 필수이다.
			String query2 = "select case m.team.name  when 'team1' then (m.age + 10)  "  +
					              "                   when 'team2' then (m.age - 10) " +
					              "                   else m.age " + 
					        "end  " +
					        "from Member m";
			List<Integer> result2 = em.createQuery(query2, Integer.class).getResultList();
			for (Integer s : result2) {
				System.out.println(s);
			}
			
			
			tx.commit();
		}catch(Exception e) {
			System.out.println("error: " + e);
			tx.rollback();
		}finally {
			em.close();
		}
		////////////////////////////////////////////////
		emf.close();
	}

}

