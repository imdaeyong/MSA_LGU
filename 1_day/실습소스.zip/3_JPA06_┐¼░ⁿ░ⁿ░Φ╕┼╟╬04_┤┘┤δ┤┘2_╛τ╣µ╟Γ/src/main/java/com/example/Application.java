
package com.example;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.entity.Member;
import com.example.entity.Product;

@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
		
		EntityManagerFactory emf =
				Persistence.createEntityManagerFactory("hello");
		//////////////////////////////////////////////////
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		try {
			
			// 다대다 연관관계 ( M:N )
			//1. 생성
			Product p = new Product();
			p.setName("prod01");
			em.persist(p);
			Product p2 = new Product();
			p2.setName("prod02");
			em.persist(p2);
			
			Member m = new Member();
			m.setName("member1");
			m.getProducts().add(p);
			m.getProducts().add(p2);
			em.persist(m);
		
			//양방향인 경우에는 양쪽에 데이터 저장
			p.getMembers().add(m);
			
			//2. 양방향 출력
			Product findProduct = em.find(Product.class, p.getId());
			System.out.println("1>>>>>>>>>>>>>>>"+findProduct);       
			List<Member> members = findProduct.getMembers();
			System.out.println("2>>>>>>>>>>>>>>>"+members);       
			for (Member member : members) {
				System.out.println("member: " + member);
			}
			
			tx.commit();
		}catch(Exception e) {
			System.out.println("error:" + e);
			tx.rollback();
		}finally {
			em.close();
		}
		////////////////////////////////////////////////
		emf.close();
	}

}

