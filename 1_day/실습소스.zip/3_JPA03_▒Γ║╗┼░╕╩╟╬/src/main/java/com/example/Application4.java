
package com.example;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.entity.Member2;
import com.example.entity.Member3;
import com.example.entity.Member4;

@SpringBootApplication
public class Application4 {

	public static void main(String[] args) {
		SpringApplication.run(Application4.class, args);
		
		EntityManagerFactory emf =
				Persistence.createEntityManagerFactory("hello");
		//////////////////////////////////////////////////
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		try {
		
			
			//3.  다. strategy=GenerationType.TABLE  실습
			Member4 z = new Member4();
			z.setName("A");
			System.out.println("==========================");
			em.persist(z);  // 시퀀스 테이블에서 id값 얻고 새로운 값으로 수정, commit할 때 사용됨
			System.out.println("Member.id:" + z.getId());
			System.out.println("==========================");
			
			
			tx.commit();
		}catch(Exception e) {
			System.out.println("error: " + e);
			tx.rollback();
		}finally {
			em.close();
		}
		////////////////////////////////////////////////
		emf.close();
	}

}

