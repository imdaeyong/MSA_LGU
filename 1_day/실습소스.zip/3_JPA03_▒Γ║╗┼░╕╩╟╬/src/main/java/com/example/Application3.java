
package com.example;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.entity.Member2;
import com.example.entity.Member3;
import com.example.entity.Member4;

@SpringBootApplication
public class Application3 {

	public static void main(String[] args) {
		SpringApplication.run(Application3.class, args);
		
		EntityManagerFactory emf =
				Persistence.createEntityManagerFactory("hello");
		//////////////////////////////////////////////////
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		try {
		
			//3.  다. strategy=GenerationType.SEQUENCE  실습
			Member3 x = new Member3();
			x.setName("A");
			System.out.println("==========================");
			em.persist(x);  // 시퀀스 객체에서 id값 얻고 commit할 때 사용됨
			System.out.println("Member.id:" + x.getId());
			System.out.println("==========================");
		
			tx.commit();
		}catch(Exception e) {
			System.out.println("error: " + e);
			tx.rollback();
		}finally {
			em.close();
		}
		////////////////////////////////////////////////
		emf.close();
	}

}

