
package com.example;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.entity.Member;
import com.example.entity.Product;

@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
		
		EntityManagerFactory emf =
				Persistence.createEntityManagerFactory("hello");
		//////////////////////////////////////////////////
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		try {
			
			// 다대다 연관관계 ( M:N )
			
			//1. 생성
			Product p = new Product();
			p.setName("prod01");
			em.persist(p);
			Product p2 = new Product();
			p2.setName("prod02");
			em.persist(p2);
			
			Member m = new Member();
			m.setName("member1");
			m.getProducts().add(p);
			m.getProducts().add(p2);
			em.persist(m);
			
			//2. 단방향
			 Member findMember = em.find(Member.class,m.getId());
			 List<Product> products = findMember.getProducts();
			 for (Product product : products) {
				 System.out.println("product:  " +  product);
			 }
			
			
			tx.commit();
		}catch(Exception e) {
			System.out.println("error:" + e);
			tx.rollback();
		}finally {
			em.close();
		}
		////////////////////////////////////////////////
		emf.close();
	}

}

