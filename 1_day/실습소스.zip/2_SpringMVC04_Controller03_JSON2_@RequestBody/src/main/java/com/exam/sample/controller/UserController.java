package com.exam.sample.controller;


import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.exam.sample.dto.User;

/*

{"userid":"홍길동","passwd":"1234"}


[{"userid":"홍길동","passwd":"1234"},{"userid":"홍길동2","passwd":"9999"}]

 */

@RestController
public class UserController {

	@RequestMapping("/")
	public String main() {
		return "index";
	}

	@CrossOrigin
	@RequestMapping(value = "/aaa", method = RequestMethod.POST)
	public @ResponseBody User xxx2(@RequestBody User dto) {
		
		System.out.println(dto);
		return dto;
	}
	
	@RequestMapping(value = "/bbb", method = RequestMethod.POST)
	public @ResponseBody List<User> xxx3(@RequestBody List<User> list) {
		
		System.out.println(list);
		return list;
	}
	
}
