package com.exam.sample.controller;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.exam.sample.dto.CustomerDTO;
import com.exam.sample.entity.Customer;
import com.exam.sample.service.CustomerService;


@RestController
public class CustomerController {

	@Autowired
	CustomerService service;
	
	@GetMapping("/cust")
	public List<CustomerDTO> retrieveCustomerList() {
		List<CustomerDTO> result = service.retrieveCustomerList();
		return result;
	}
	
	@GetMapping("/cust/{id}")
	public CustomerDTO retrieveCustomer(@PathVariable String id) {
		CustomerDTO dto = service.retrieveCustomer(id);
		return dto;
	}
	
	@GetMapping("/cust/v1/{name}")
	public List<CustomerDTO> retrieveCustomerByName(@PathVariable String name) {
		return service.retrieveCustomerByName(name);
	}
	
	@PostMapping("/cust")
	public String createCustomer(@RequestBody CustomerDTO customer ) {
		String id = service.createCustomer(customer);
		return id;
	}
	
	@PutMapping("/cust/{id}")
	public void updateCustomer(@PathVariable String id, @RequestBody CustomerDTO customer) {
		 service.updateCustomer(id, customer);
	}
	
	@DeleteMapping("/cust/{id}")
	public void deleteCustomer(@PathVariable String id) {
		 service.deleteCustomer(id);
	}
	//JPQL
	@GetMapping("/cust/jpql/{name}")
	public List<CustomerDTO> findCustomerListByName(String name) {
		return service.findCustomerListByName(name);
	}
	@GetMapping("/cust/jpql")
	public List<String> findStringList() {
		return service.findStringList();
	}
	@GetMapping("/cust/jpql/sort")
	public List<String> findStringSortList() {
		return service.findStringSortList("name");
	}
	@GetMapping("/cust/jpql/id/{id}/name/{name}")
	public CustomerDTO findCustomerByIdAndName(@PathVariable String id, String name) {
		return service.findCustomerByIdAndName(id, name);
	}
	@GetMapping("/cust/page/offset/{offset}/siz/{size}")
	public List<CustomerDTO> findAllCustomersWithPagination(@PathVariable int offset, 
			                                                @PathVariable int size){
		Page<CustomerDTO> xx = service.findAllCustomersWithPagination(offset, size);
		System.out.println(xx.getContent());
		return xx.getContent();
	}
	@GetMapping("/cust/page/name/{name}/offset/{offset}/siz/{size}")
	public List<CustomerDTO> findByNameCustomersWithPagination(@PathVariable String name, 
			@PathVariable int offset, 
			@PathVariable int size){
		Page<CustomerDTO> xx = service.findByNameCustomersWithPagination(name, offset, size);
		System.out.println(xx.getContent());
		return xx.getContent();
	}
}





