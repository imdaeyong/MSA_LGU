package com.exam.sample.repository;

import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.exam.sample.entity.Customer;

@Repository
public interface SpringDataJpaCustomerRepository extends JpaRepository<Customer, String> {

	List<Customer> findByName(String name);
	
	@Query(value = "select c from Customer c where c.name = :name")
	List<Customer> findCustomerListByName(String name);
	
	@Query(value = "select c.name from Customer c")
	List<String> findStringList();
	
	@Query("select c from Customer c WHERE c.id = ?1 and c.name = ?2")
	Customer findCustomerByIdAndName(String id, String name);
	
	@Query(value = "select c.name from Customer c")
	List<String> findStringSortList(Sort sort);
	
	@Query(value = "select c from Customer c ORDER BY name")
	Page<Customer> findAllCustomersWithPagination(Pageable pageable);
	
	@Query(value = "select c from Customer c where c.name = :name  ORDER BY name")
	Page<Customer> findByNameCustomersWithPagination(String name, Pageable pageable);
	
	
}
