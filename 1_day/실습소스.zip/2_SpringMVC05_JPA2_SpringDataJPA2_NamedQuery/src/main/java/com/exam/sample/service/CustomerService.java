package com.exam.sample.service;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import com.exam.sample.dto.CustomerDTO;
import com.exam.sample.entity.Customer;


public interface CustomerService {

	
	String createCustomer(CustomerDTO customer);
	CustomerDTO retrieveCustomer(String id);
	List<CustomerDTO> retrieveCustomerByName(String name);
	List<CustomerDTO> retrieveCustomerList();
	
	void updateCustomer(String id, CustomerDTO customer);
	void deleteCustomer(String id);
	
	//JPQL
	List<CustomerDTO> findCustomerListByName(String name);
	List<String> findStringList();
	CustomerDTO findCustomerByIdAndName(String id, String name);
	
	List<String> findStringSortList(String v);
	
	Page<CustomerDTO> findAllCustomersWithPagination(int offset, int size);
	Page<CustomerDTO> findByNameCustomersWithPagination(String name, int offset, int size);
}
