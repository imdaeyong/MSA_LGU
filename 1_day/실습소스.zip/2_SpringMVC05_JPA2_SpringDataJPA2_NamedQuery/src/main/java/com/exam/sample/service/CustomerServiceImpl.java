package com.exam.sample.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.exam.sample.dto.CustomerDTO;
import com.exam.sample.entity.Customer;
import com.exam.sample.repository.SpringDataJpaCustomerRepository;

@Service
@Transactional
public class CustomerServiceImpl implements CustomerService {

	private SpringDataJpaCustomerRepository repository;

	public CustomerServiceImpl(SpringDataJpaCustomerRepository repository) {
		this.repository = repository;
	}

	@Override
	public String createCustomer(CustomerDTO dto) {
///////// Customer에 setter 메서드가 없기 때문에 값이 설정이 안된다. //////////////////////////////////
//		ModelMapper mapper = new ModelMapper();
//		Customer entity = mapper.map(customer, Customer.class);
///////////////////////////////////////////////////////////////
		Customer entity = Customer.builder()
								  .id(dto.getId())
								  .name(dto.getName())
								  .build();
		
		repository.save(entity);

		return dto.getId();
	}

	@Override
	public CustomerDTO retrieveCustomer(String id) {
////////////////////////////////////////////////////////////////
		ModelMapper mapper = new ModelMapper();
		Customer result = repository.findById(id).orElse(null);
		CustomerDTO dto = mapper.map(result, CustomerDTO.class);
///////////////////////////////////////////////////////////////
		return dto;
	}

	@Override
	public List<CustomerDTO> retrieveCustomerByName(String name) {
////////////////////////////////////////////////////////////////
		ModelMapper mapper = new ModelMapper();
		List<Customer> result = repository.findByName(name);
		System.out.println("CustomerServiceImpl.findByName:" + result);
//		List<CustomerDTO> list = mapper.map(result, List.class); 안됨
		List<CustomerDTO> list = 
				result.stream().map(p -> mapper.map(p, CustomerDTO.class)).collect(Collectors.toList());
///////////////////////////////////////////////////////////////
		return list;
	}

	@Override
	public List<CustomerDTO> retrieveCustomerList() {
////////////////////////////////////////////////////////////////
		ModelMapper mapper = new ModelMapper();
		List<Customer> result = repository.findAll();
//		List<CustomerDTO> list = mapper.map(result, List.class);
		List<CustomerDTO> list = 
				result.stream().map(p -> mapper.map(p, CustomerDTO.class)).collect(Collectors.toList());
///////////////////////////////////////////////////////////////
		return list;
	}


	@Override
	public void updateCustomer(String id, CustomerDTO dto) {

		Customer customer = repository.findById(id).orElse(null);
		customer.updateCustomer(dto);
	}

	@Override
	public void deleteCustomer(String id) {
		Customer findCustomer = repository.findById(id).orElse(null);
		repository.delete(findCustomer);
	}
	
	//JPQL 실습

	@Override
	public List<CustomerDTO> findCustomerListByName(String name) {
////////////////////////////////////////////////////////////////
		ModelMapper mapper = new ModelMapper();
		List<Customer> result = repository.findCustomerListByName(name);
		List<CustomerDTO> list = mapper.map(result, List.class);
///////////////////////////////////////////////////////////////
		return list;
	}

	@Override
	public List<String> findStringList() {
		List<String> result = repository.findStringList();
		return result;
	}

	@Override
	public List<String> findStringSortList(String v) {
		return repository.findStringSortList(Sort.by(v).descending());
	}

	@Override
	public CustomerDTO findCustomerByIdAndName(String id, String name) {
////////////////////////////////////////////////////////////////
		ModelMapper mapper = new ModelMapper();
		Customer entity = repository.findCustomerByIdAndName(id, name);
		CustomerDTO dto = mapper.map(entity, CustomerDTO.class);
///////////////////////////////////////////////////////////////
		return dto;
	}

	@Override
	public Page<CustomerDTO> findAllCustomersWithPagination(int offset, int size) {

		Pageable firstPageWithTwoElements = PageRequest.of(offset, size);
////////////////////////////////////////////////////////////////
		ModelMapper mapper = new ModelMapper();
		Page<Customer> entity = repository.findAllCustomersWithPagination(firstPageWithTwoElements);
		Page<CustomerDTO> dto = mapper.map(entity, Page.class);
///////////////////////////////////////////////////////////////
		return dto;
	}

	@Override
	public Page<CustomerDTO> findByNameCustomersWithPagination(String name, int offset, int size) {

		Pageable firstPageWithTwoElements = PageRequest.of(offset, size);
////////////////////////////////////////////////////////////////
		ModelMapper mapper = new ModelMapper();
		Page<Customer> entity = repository.findByNameCustomersWithPagination(name, firstPageWithTwoElements);
		Page<CustomerDTO> dto = mapper.map(entity, Page.class);
///////////////////////////////////////////////////////////////
		return dto;
	}

}
