package com.exam.sample.controller;

import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.exam.sample.dto.UserDTO;

@Controller
public class UserController {


	
	@RequestMapping(value = "/a" , method=RequestMethod.GET)
	public String a() {
		return "a";
	}
	
	@Autowired
	ServletContext application;
	
	@RequestMapping(value = "/a2" , method=RequestMethod.GET)
	public String a2(Model m, HttpSession session) {
		m.addAttribute("username", "홍길동1");
		session.setAttribute("username", "홍길동2");
		application.setAttribute("username", "홍길동3");
		return "a2";
	}
	
	
	@RequestMapping(value = "/a3" , method=RequestMethod.GET)
	public String a3(Model m) {
		//lombok
		UserDTO dto = new UserDTO();
		dto.setUsername("홍길동");
		dto.setAge(20);

		m.addAttribute("user", dto);
		return "a3";
	}
	
	@RequestMapping(value = "/a4" , method=RequestMethod.GET)
	public String a4(Model m) {
		m.addAttribute("user", new UserDTO("홍길동", 20));
		m.addAttribute("user2", new UserDTO("hong", 20));

		List<UserDTO> list = 
				Arrays.asList(new UserDTO("홍길동1", 20), 
						new UserDTO("홍길동2", 30),
						new UserDTO("홍길동3", 40));
		m.addAttribute("userList", list);
		return "a4";
	}
}
