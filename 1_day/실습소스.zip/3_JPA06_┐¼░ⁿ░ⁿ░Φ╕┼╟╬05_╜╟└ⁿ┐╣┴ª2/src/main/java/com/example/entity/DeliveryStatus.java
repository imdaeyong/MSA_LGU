package com.example.entity;

public enum DeliveryStatus {
	ING,DONE
}
