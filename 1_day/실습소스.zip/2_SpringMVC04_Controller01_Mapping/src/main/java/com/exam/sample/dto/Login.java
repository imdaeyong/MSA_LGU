package com.exam.sample.dto;

import lombok.Data;

@Data
public class Login {

	private String userid;
	private String passwd;
	
}
