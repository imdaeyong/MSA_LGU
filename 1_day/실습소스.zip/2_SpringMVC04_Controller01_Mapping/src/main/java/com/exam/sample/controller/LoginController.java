package com.exam.sample.controller;

import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.exam.sample.dto.Login;

@Controller
public class LoginController {

	//GET
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String loginForm() {
		return "loginForm";
	}


	// POST
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String login9(Login dto) {
		System.out.println("Login dto 이용");
		System.out.println(dto);
		return "login";
	}

	// POST
	@RequestMapping(value = "/login8", method = RequestMethod.POST)
	public String login8(@ModelAttribute Login dto) {
		System.out.println("@ModelAttribute Login dto 이용");
		System.out.println(dto);
		return "login";
	}

	
	@RequestMapping(value = "/login7", method = RequestMethod.POST)
	public String login7(@RequestParam Map<String, String> map) {
		System.out.println("@RequestParam Map<String, String> map 이용");
		System.out.println(map);
		return "login";
	}

	@RequestMapping(value = "/login6", method = RequestMethod.POST)
	public String login6(@RequestParam(value = "userid2", required = false, defaultValue = "유관순") String id,
			@RequestParam(value = "passwd") int pw) {
		System.out.println(id + "\t" + pw);
		return "login";
	}

	@RequestMapping(value = "/login5", method = RequestMethod.POST)
	public String login5(String userid, String passwd) {
		System.out.println("String userid 이용");
		System.out.println(userid + "\t" + passwd);
		return "login";
	}

	@RequestMapping(value = "/login4", method = RequestMethod.POST)
	public String login4(@RequestParam String userid, @RequestParam String passwd) {
		System.out.println("@RequestParam String userid이용");
		System.out.println(userid + "\t" + passwd);
		return "login";
	}

	@RequestMapping(value = "/login3", method = RequestMethod.POST)
	public String login3(@RequestParam("userid") String id, @RequestParam("passwd") String pw) {
		System.out.println("@RequestParam(\"userid\") String userid이용");
		System.out.println(id + "\t" + pw);
		return "login";
	}

	@RequestMapping(value = "/login2", method = RequestMethod.POST)
	public String login2(HttpServletRequest request) {
		String id = request.getParameter("userid");
		String pw = request.getParameter("passwd");
		System.out.println("HttpServletRequest 이용");
		System.out.println(id + "\t" + pw);
		return "login";
	}
}
