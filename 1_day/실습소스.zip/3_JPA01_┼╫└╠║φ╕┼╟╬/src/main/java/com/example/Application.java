/*
 *  H2에서 새로운 데이터베이스 생성방법
 *  https://sogno-ing.tistory.com/169?category=836518
 * 
 *  주의할 점은 
 *  2_2) 항목에서  ./newDB 대신에  ~/newDB 사용한다.  ( ~ 의미는 사용자 디렉토리 의미)
 *      .으로 사용하면 IOException이 발생됨.
 *      
 *      ALTER USER SA SET PASSWORD '';
 *      
 */
package com.example;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.entity.Member;

@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
		
		EntityManagerFactory emf =
				Persistence.createEntityManagerFactory("hello");
		//////////////////////////////////////////////////
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		try {
		
			
			tx.commit();
		}catch(Exception e) {
			tx.rollback();
		}finally {
			em.close();
		}
		////////////////////////////////////////////////
		emf.close();
	}

}

