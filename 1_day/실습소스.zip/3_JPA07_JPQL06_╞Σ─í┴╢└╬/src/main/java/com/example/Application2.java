package com.example;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.entity.Member;
import com.example.entity.Team;

@SpringBootApplication
public class Application2 {

	public static void main(String[] args) {
		SpringApplication.run(Application2.class, args);
		
		EntityManagerFactory emf =
				Persistence.createEntityManagerFactory("hello");
		//////////////////////////////////////////////////
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		try {
					
			Team teamA = new  Team();
			teamA.setName("팀A");
			em.persist(teamA);

			Team teamB = new  Team();
			teamB.setName("팀B");
			em.persist(teamB);
			
			Team teamC = new  Team();
			teamC.setName("팀C");
			em.persist(teamC);
			
			Member member1 = new Member();
			member1.setUsername("회원1");
			member1.setTeam(teamA);
			em.persist(member1);
			
			Member member2 = new Member();
			member2.setUsername("회원2");
			member2.setTeam(teamA);
			em.persist(member2);
			
			
			Member member3 = new Member();
			member3.setUsername("회원3");
			member3.setTeam(teamB);
			em.persist(member3);
			
			em.flush();
			em.clear();
			
			//4. Fetch JOIN ( 한번의 SQL문에서 Member 와 Team을 조인해서 모든 데이터를 가져온다. )
			// N + 1 문제를 해결할 수 있다.
			List<Member> result = em.createQuery("select m from Member m join fetch m.team", Member.class).getResultList();
			for (Member s : result) {
				System.out.println("1: Fetch JOIN :  " + s +"\t" + s.getTeam().getName());
			}
			
			
			tx.commit();
		}catch(Exception e) {
			System.out.println("error: " + e);
			tx.rollback();
		}finally {
			em.close();
		}
		////////////////////////////////////////////////
		emf.close();
	}

}

