package com.example;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.entity.Member;
import com.example.entity.Team;

@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
		
		EntityManagerFactory emf =
				Persistence.createEntityManagerFactory("hello");
		//////////////////////////////////////////////////
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		try {
					
			Team teamA = new  Team();
			teamA.setName("팀A");
			em.persist(teamA);

			Team teamB = new  Team();
			teamB.setName("팀B");
			em.persist(teamB);
			
			Team teamC = new  Team();
			teamC.setName("팀C");
			em.persist(teamC);
			
			Member member1 = new Member();
			member1.setUsername("회원1");
			member1.setTeam(teamA);
			em.persist(member1);
			
			Member member2 = new Member();
			member2.setUsername("회원2");
			member2.setTeam(teamA);
			em.persist(member2);
			
			
			Member member3 = new Member();
			member3.setUsername("회원3");
			member3.setTeam(teamB);
			em.persist(member3);
			
			
			em.flush();
			em.clear();
			
			//1. Member 정보만 가져오는 경우
			List<Member> result = em.createQuery("select m from Member m", Member.class).getResultList();
			for (Member s : result) {
				System.out.println("1: Member 정보만 가져오는 경우:  " + s);
			}
			em.flush();
			em.clear();
			//2. Team 정보만 가져오는 경우 ( 내부적으로 Inner 조인 됨 )
			List<Team> result2 = em.createQuery("select m.team from Member m", Team.class).getResultList();
			for (Team s : result2) {
				System.out.println("2: Team 정보만 가져오는 경우:  " + s);
			}
			em.flush();
			em.clear();
			//3. Lazy 조인을 이용하여 Member + Team 정보 출력 ( Member 따로 Team 따로 SQL 실행됨 )
			// 즉, 많은 수의 SQL문이 실행될 수 있기 때문에 성능이 떨어진다. ( N + 1  문제 발생 : 1번의 SQL문으로 인해서 N번의 SQL문이 추가로 실행되는 문제)
			List<Member> result3 = em.createQuery("select m from Member m", Member.class).getResultList();
			for (Member s : result3) {
				System.out.println("3: Member + Team 정보:  " + s +"\t>>" + s.getTeam().getName());
				// 회원1, 팀A(SQL)
				// 회원2, 팀A(1차캐시)
				// 회원3, 팀B(SQL)
			}
			
			
			tx.commit();
		}catch(Exception e) {
			System.out.println("error: " + e);
			tx.rollback();
		}finally {
			em.close();
		}
		////////////////////////////////////////////////
		emf.close();
	}

}

