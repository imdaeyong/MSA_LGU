insert into ORDERS ( order_id, user_id, name,  product_id, quantity, unit_price, total_price) 
        values ('A1111', '1111', '홍길동','CATALOG-0001', 10, 500, 5000);
insert into ORDERS ( order_id, user_id, name,  product_id, quantity, unit_price, total_price) 
        values ('B1111', '1111', '홍길동','CATALOG-0002', 5, 200, 1000);
insert into ORDERS ( order_id, user_id, name,  product_id, quantity, unit_price, total_price) 
        values ('C1111', '2222', '이순신','CATALOG-0003', 10, 100, 1000);
insert into ORDERS ( order_id, user_id, name,  product_id, quantity, unit_price, total_price) 
        values ('D1111', '3333', '유관순','CATALOG-0004', 15, 100, 1500);
insert into ORDERS ( order_id, user_id, name,  product_id, quantity, unit_price, total_price) 
        values ('E1111', '3333', '유관순','CATALOG-0005', 4, 100, 400);
insert into ORDERS ( order_id, user_id, name,  product_id, quantity, unit_price, total_price) 
        values ('F1111', '4444', '세종','CATALOG-0004', 15, 100, 1500);                