DROP TABLE IF EXISTS ORDERS;

CREATE TABLE ORDERS
(
  ORDER_ID          VARCHAR(50) not null, 
  USER_ID            VARCHAR(50) not null,
  NAME 	           VARCHAR(20),
  PRODUCT_ID       VARCHAR(50), 
  QUANTITY             INTEGER,
  UNIT_PRICE         INTEGER,
  TOTAL_PRICE       INTEGER,
  CREATE_DATE   DATE DEFAULT CURRENT_DATE
);

alter table ORDERS
  add primary key (ORDER_ID);
