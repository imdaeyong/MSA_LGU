package com.exam.sample.order.controller;


import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.exam.sample.order.dto.OrderDTO;
import com.exam.sample.order.service.OrderService;

import io.swagger.annotations.ApiOperation;

@RestController
public class OrderController {
	
	@Autowired
	OrderService orderService;
	
	@GetMapping(value="/order/v1")
	public List<OrderDTO> retrieveOrderList() throws Exception{
		return orderService.retrieveOrderList();
	}
	
	
	@ApiOperation(value = "주문 조회", httpMethod = "GET", notes = "주문 조회")
	@GetMapping(value="/order/v1/{userid}")
	public List<OrderDTO> retrieveOrderByUserId(@PathVariable("userid") String userid) throws Exception{
		return orderService.retrieveOrderByUserId(userid);
	}

	@GetMapping(value="/orders/{userid}/{quantity}")
	public List<OrderDTO> retrieveUserIdAndQuantity(@PathVariable("userid") String userid, @PathVariable int quantity) throws Exception{
		return orderService.retrieveUserIdAndQuantity(userid, quantity);
	}
	@GetMapping(value="/orders/orderIdList")
	public List<OrderDTO> retrieveOrderIdIn() throws Exception{
		List<String> orderIdList = Arrays.asList("A1111","C1111","D1111");
		return orderService.retrieveOrderIdIn(orderIdList);
	}
	@GetMapping(value="/orders/{unitPrice}")
	public List<OrderDTO> retrieveUnitPriceLessThan(@PathVariable int unitPrice) throws Exception{
		return orderService.retrieveUnitPriceLessThan(unitPrice);
	}
}
