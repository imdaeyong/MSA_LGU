package com.exam.sample.order.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.exam.sample.order.entity.OrderEntity;


// https://docs.spring.io/spring-data/jpa/docs/2.5.4/reference/html/#repositories.query-methods.details
@Repository
public interface SpringDataJpaOrderRepository extends JpaRepository<OrderEntity, String> {

	List<OrderEntity> findAllByUserId(String userid);
	
	List<OrderEntity> findByUserIdAndQuantity(String userid, int quantity);
	
	List<OrderEntity>  findByOrderIdIn(List<String> orderIdList);
	
	List<OrderEntity>  findByUnitPriceLessThan(int unitPrice);
	
}
