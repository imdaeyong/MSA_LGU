package com.exam.sample.order.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OrderDTO {

	private String orderId; //pk
	private String userId;
	private String name;
	private String productId;
	private int quantity;
	private int unitPrice;
	private int totalPrice;
	private LocalDateTime createDate;
}
