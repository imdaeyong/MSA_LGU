package com.exam.sample.order.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import com.exam.sample.order.dto.OrderDTO;
import com.exam.sample.order.entity.OrderEntity;
import com.exam.sample.order.repository.SpringDataJpaOrderRepository;

@Service("orderService")
public class OrderServiceImpl implements OrderService {

	private SpringDataJpaOrderRepository repository;

	public OrderServiceImpl(SpringDataJpaOrderRepository repository) {
		this.repository = repository;
	}

	@Override
	public List<OrderDTO> retrieveOrderByUserId(String userid) {

////////////////////////////////////////////////////////////////
		ModelMapper mapper = new ModelMapper();
		List<OrderEntity> result = repository.findAllByUserId(userid);
		//List<OrderDTO> list = mapper.map(result, List.class);
		List<OrderDTO> collect = 
				result.stream().map(p -> mapper.map(p, OrderDTO.class)).collect(Collectors.toList());
///////////////////////////////////////////////////////////////
		return collect;
	}
	

	@Override
	public List<OrderDTO> retrieveUserIdAndQuantity(String userid, int quantity) {
		
		List<OrderEntity> orderEntityList = repository.findByUserIdAndQuantity(userid, quantity);
		List<OrderDTO> orderDTOList = toOrderDTOList(orderEntityList);
		return orderDTOList;
	}

	@Override
	public List<OrderDTO> retrieveOrderIdIn(List<String> orderIdList) {
		List<OrderEntity> orderEntityList = repository.findByOrderIdIn(orderIdList);
		List<OrderDTO> orderDTOList = toOrderDTOList(orderEntityList);
		return orderDTOList;
	}

	@Override
	public List<OrderDTO> retrieveUnitPriceLessThan(int unitPrice) {
		List<OrderEntity> orderEntityList = repository.findByUnitPriceLessThan(unitPrice);
		List<OrderDTO> orderDTOList = toOrderDTOList(orderEntityList);
		return orderDTOList;
	}
	
	
	
	//Entity ==> DTO
	public OrderDTO toOrderDTO(OrderEntity order) {
		if(order == null) {
			return null;
		}
		
		//Builder패턴
		OrderDTO dto = OrderDTO.builder()
						.name(order.getName())
						.createDate(order.getCreateDate())
						.orderId(order.getOrderId())
						.productId(order.getProductId())
						.quantity(order.getQuantity())
						.totalPrice(order.getTotalPrice())
						.unitPrice(order.getUnitPrice())
						.userId(order.getUserId())
						.build();
		
		return dto;
		
	}
	
	// List<Entity> ==> List<DTO>
	public List<OrderDTO> toOrderDTOList(List<OrderEntity> orders){
		if(orders == null) {
			return null;
		}
		
		List<OrderDTO> list = new ArrayList<OrderDTO>(orders.size());
		for(OrderEntity order : orders) {
			list.add(toOrderDTO(order));
		}
		return list;
	}

	@Override
	public List<OrderDTO> retrieveOrderList() {
		List<OrderEntity> orderEntityList = repository.findAll();
		return toOrderDTOList(orderEntityList);
	}
}
