package com.example.entity;

public enum OrderStatus {
	ORDER, CANCEL
}
