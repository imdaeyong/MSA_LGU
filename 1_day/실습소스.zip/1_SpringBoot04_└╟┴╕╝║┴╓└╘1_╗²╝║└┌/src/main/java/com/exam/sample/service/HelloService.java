package com.exam.sample.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

import com.exam.sample.repository.HelloRepository;

@Service
public class HelloService {

	private HelloRepository repository;
	
	// 생성자 이용하여 주입 받는다.
	public HelloService(HelloRepository repository) {
		this.repository = repository;
	}
	
	public List<String> list(){
		return repository.list();
	}
}
