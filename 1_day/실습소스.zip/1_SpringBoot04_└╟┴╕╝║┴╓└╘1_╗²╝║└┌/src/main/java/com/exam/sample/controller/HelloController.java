package com.exam.sample.controller;

import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.exam.sample.service.HelloService;

@RestController
public class HelloController {

	private HelloService service;
	
	// 생성자 이용하여 주입 받는다.
	public HelloController(HelloService service) {
		this.service = service;
	}
	
	
	@RequestMapping(value="/hello", method=RequestMethod.GET)
	public List<String> hello() {
		return service.list();
	}
}
