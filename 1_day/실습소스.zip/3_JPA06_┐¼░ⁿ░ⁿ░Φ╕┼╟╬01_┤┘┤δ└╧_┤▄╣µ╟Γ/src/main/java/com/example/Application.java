
package com.example;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.entity.Member;
import com.example.entity.Team;

@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
		
		EntityManagerFactory emf =
				Persistence.createEntityManagerFactory("hello");
		//////////////////////////////////////////////////
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		try {
			
			// 단방향 연관관계 ( N:1 )
			//1. 데이터 저장
			Team team = new  Team();
			team.setName("teamA");
			em.persist(team);
			
			Member member = new Member();
			member.setName("member1");
			member.setTeam(team); //단방향 연관관계 설정, 참조 저장
			em.persist(member);
			
			//2. 연관관계 수정
			//새로운 팀B
			Team teamB = new Team();
			teamB.setName("teamB");
			em.persist(teamB);
			member.setTeam(teamB);
			
			
			//3. 연관관계 조회 - 객체그래프 탐색해서 Team 정보까지 조회됨
			Member findMember = em.find(Member.class, member.getId());
			System.out.println("findMember:" + findMember);
			
			Team findTeam = findMember.getTeam();
			System.out.println("findTeam:" + findTeam);
			
			
			
			tx.commit();
		}catch(Exception e) {
			System.out.println("error:" + e);
			tx.rollback();
		}finally {
			em.close();
		}
		////////////////////////////////////////////////
		emf.close();
	}

}

