package com.exam.sample.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Customer {

	@ApiModelProperty(dataType = "String" , example = "inky4832")
	private String userid;
	@ApiModelProperty(dataType = "String" , example = "1234")
	private String passwd;
	
}
