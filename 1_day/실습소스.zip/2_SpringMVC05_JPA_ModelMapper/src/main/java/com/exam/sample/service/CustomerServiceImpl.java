package com.exam.sample.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import com.exam.sample.dto.CustomerDTO;
import com.exam.sample.entity.Customer;
import com.exam.sample.repository.CustomerRepository;

@Service
@Transactional
public class CustomerServiceImpl implements CustomerService {

	private CustomerRepository repository;

	//생성자 주입
	public CustomerServiceImpl(CustomerRepository repository) {
		this.repository = repository;
	}

	@Override
	public String createCustomer(CustomerDTO dto) {
///////// Customer에 setter 메서드가 없기 때문에 값이 설정이 안된다. //////////////////////////////////
//		ModelMapper mapper = new ModelMapper();
//		Customer entity = mapper.map(customer, Customer.class);
///////////////////////////////////////////////////////////////
		Customer entity = Customer.builder()
								  .id(dto.getId())
								  .name(dto.getName())
								  .build();
		
		repository.save(entity);

		return dto.getId();
	}

	@Override
	public CustomerDTO retrieveCustomer(String id) {
////////////////////////////////////////////////////////////////
		ModelMapper mapper = new ModelMapper();
		Customer result = repository.findById(id);
		CustomerDTO dto = mapper.map(result, CustomerDTO.class);
///////////////////////////////////////////////////////////////
		return dto;
	}

	@Override
	public List<CustomerDTO> retrieveCustomerByName(String name) {
////////////////////////////////////////////////////////////////
		ModelMapper mapper = new ModelMapper();
		List<Customer> result = repository.findByName(name);
		System.out.println("CustomerServiceImpl.findByName:" + result);
//		List<CustomerDTO> list = mapper.map(result, List.class); 안됨
		List<CustomerDTO> list = 
				result.stream().map(p -> mapper.map(p, CustomerDTO.class)).collect(Collectors.toList());
///////////////////////////////////////////////////////////////
		return list;
	}

	@Override
	public List<CustomerDTO> retrieveCustomerList() {
////////////////////////////////////////////////////////////////
		ModelMapper mapper = new ModelMapper();
		List<Customer> result = repository.findAll();
//		List<CustomerDTO> list = mapper.map(result, List.class);
		List<CustomerDTO> list = 
				result.stream().map(p -> mapper.map(p, CustomerDTO.class)).collect(Collectors.toList());
///////////////////////////////////////////////////////////////
		return list;
	}

	@Override
	public void updateCustomer(String id, CustomerDTO dto) {

		Customer customer = repository.findById(id);
		customer.updateCustomer(dto);
	}

	@Override
	public void deleteCustomer(String id) {
		repository.remove(id);
	}

}
