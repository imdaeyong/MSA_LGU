package com.exam.sample.dto;

import lombok.Data;

@Data
public class CustomerDTO {

	private String id;
	private String name;
	
}
