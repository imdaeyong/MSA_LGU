package com.example;

import java.util.Arrays;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.entity.Member;
import com.example.entity.Team;

@SpringBootApplication
public class Application2 {

	public static void main(String[] args) {
		SpringApplication.run(Application2.class, args);
		
		EntityManagerFactory emf =
				Persistence.createEntityManagerFactory("hello");
		//////////////////////////////////////////////////
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		try {
			
			
			Team team = new  Team();
			team.setName("team1");
			
			Team team2 = new  Team();
			team2.setName("team2");
			
			em.persist(team);
			em.persist(team2);
			
			Member m1 = new Member("aaa1", 10, team);
			Member m2 = new Member("aaa2", 20, team2);
			Member m3 = new Member("aaa3", 30, team);
			Member m4 = new Member("aaa4", 40, team2);
			
			em.persist(m1);
			em.persist(m2);
			em.persist(m3);
			em.persist(m4);
			///////////////////////////////////////////////////
			//4. 스칼라의 여러 값 조회
			
			//가. Query 타입으로 반환
			List resultList =  em.createQuery("select m.username, m.age from Member m")
			                   .getResultList();
			 for (Object o : resultList) {
				Object[] objArr = (Object[])o;
					System.out.println(objArr[0] +"\t" +objArr[1] +"\t\t" + Arrays.toString(objArr));
			}
			
			//나. Object [] 타입으로 반환
			 List<Object[]> resultList2 = em.createQuery("select m.username, m.age from Member m")
					 					 .getResultList();
			 for (Object [] objArr : resultList2) {
				 System.out.println(objArr[0] +"\t"+ objArr[1] +"\t\t" + Arrays.toString(objArr));
			 }
			 
	
			///////////////////////////////////////////////////
			tx.commit();
		}catch(Exception e) {
			System.out.println("error: " + e);
			tx.rollback();
		}finally {
			em.close();
		}
		////////////////////////////////////////////////
		emf.close();
	}

}

