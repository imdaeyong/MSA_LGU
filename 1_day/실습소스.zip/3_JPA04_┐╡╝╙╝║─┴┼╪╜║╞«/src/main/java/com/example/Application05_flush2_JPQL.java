
package com.example;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.entity.Member;

@SpringBootApplication
public class Application05_flush2_JPQL {

	public static void main(String[] args) {
		SpringApplication.run(Application05_flush2_JPQL.class, args);

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hello");
		//////////////////////////////////////////////////
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		try {

			// flush ==> 엔티티 컨텍스트의 내용을 실제 DB에 반영
			/*
			 * flush가 실행되는 경우 1. em.flush() 2. tx.commit() 3. JPQL 사용시
			 * 
			 * flush 모드 옵션
			 * ==> em.setFlushMode(FlushModeType.AUTO)
			 * 
			 *  1) FlushModeType.AUTO (기본)
			 *    커밋이나 쿼리를 실행할 때 플러시 동작
			 *  
			 *  2) FlushModeType.COMMIT
			 *    커밋할 때만 플러시 동작
			 *    
			 * 특징
			 *  1) 영속성 컨텍스트를 비우지 않음
			 *  2) 영속성 컨텍스트의 변경 내용을 데이터베이스에 동기화
			 *  3) 트랜잭션 개념이 중요
			 * 
			 */
			Member m1 = new Member(601L, "member");
			Member m2 = new Member(602L, "member");
			Member m3 = new Member(603L, "member");
			em.persist(m1);
			em.persist(m2);
			em.persist(m3);

			List<Member> result = em.createQuery("select m from Member as m", Member.class).setFirstResult(1)
					.setMaxResults(3).getResultList();
			System.out.println(result); // commit되기 전에 flush 되어서 SQL문장이 미리 실행됨.
			System.out.println("=====================================");
			tx.commit();
		} catch (Exception e) {
			System.out.println("error:" + e);
			tx.rollback();
		} finally {
			em.close();
		}
		////////////////////////////////////////////////
		emf.close();
	}

}
