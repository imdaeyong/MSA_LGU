package com.example;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.entity.Member;
import com.example.entity.Team;

@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
		
		EntityManagerFactory emf =
				Persistence.createEntityManagerFactory("hello");
		//////////////////////////////////////////////////
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		try {
					
			for(int i=1; i <=100; i++) {
				Member m1 = new Member("member"+i, i, null);
				em.persist(m1);
			}
			
			em.flush();
			em.clear();
			
			List<Member> members = em.createQuery("select m from Member m order by m.age desc", Member.class)
									.setFirstResult(1)
									.setMaxResults(10)
									.getResultList();
			
			for (Member member : members) {
				System.out.println("member: " + member);
			}
			
			 
			tx.commit();
		}catch(Exception e) {
			System.out.println("error: " + e);
			tx.rollback();
		}finally {
			em.close();
		}
		////////////////////////////////////////////////
		emf.close();
	}

}

